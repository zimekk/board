(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-10a7d969.js")
    );
  })().catch(console.error);

})();
