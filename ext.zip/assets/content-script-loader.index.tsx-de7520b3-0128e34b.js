(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-de7520b3.js")
    );
  })().catch(console.error);

})();
