(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-a1ee2bff.js")
    );
  })().catch(console.error);

})();
