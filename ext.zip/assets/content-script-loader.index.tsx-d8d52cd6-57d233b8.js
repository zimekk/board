(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-d8d52cd6.js")
    );
  })().catch(console.error);

})();
