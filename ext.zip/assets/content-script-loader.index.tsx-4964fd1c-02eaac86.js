(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-4964fd1c.js")
    );
  })().catch(console.error);

})();
