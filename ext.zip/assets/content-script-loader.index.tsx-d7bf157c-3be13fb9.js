(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-d7bf157c.js")
    );
  })().catch(console.error);

})();
