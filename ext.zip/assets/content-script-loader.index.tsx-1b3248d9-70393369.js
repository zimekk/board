(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-1b3248d9.js")
    );
  })().catch(console.error);

})();
