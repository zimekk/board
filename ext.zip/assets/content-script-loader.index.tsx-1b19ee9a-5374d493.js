(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-1b19ee9a.js")
    );
  })().catch(console.error);

})();
