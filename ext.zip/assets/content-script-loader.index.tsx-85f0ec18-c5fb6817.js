(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-85f0ec18.js")
    );
  })().catch(console.error);

})();
