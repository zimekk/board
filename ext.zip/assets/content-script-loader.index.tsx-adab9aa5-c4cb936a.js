(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-adab9aa5.js")
    );
  })().catch(console.error);

})();
