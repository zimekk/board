(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-8e0b68cb.js")
    );
  })().catch(console.error);

})();
